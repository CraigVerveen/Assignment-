package Assignment;

import java.util.ArrayList;
import java.util.Scanner;      // Required for the scanner
import java.io.File;               // Needed for file and IOException 
import java.io.FileNotFoundException; //Required for exception throw**
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;



public class gui extends JFrame 
implements ActionListener
{


   JButton button1;
   JTextField field1;
   JLabel label1;
   
   
   // Basic Screen Constructor
   gui(String title)
   {
	   
	   super(title);
	   setSize(300,300);
	   setLayout(new FlowLayout());
	   field1 = new JTextField(21);
	   add(field1);
	   label1 = new JLabel("Enter A Counrty:");
	   add(label1);
	   button1 = new JButton("Search");
	   add(button1);
	   setVisible(true);
	   button1.addActionListener(this);	   
	   }
   
   
   public void checkname() throws FileNotFoundException{
	   
	// ask the user for the search string
       Scanner keyboard = new Scanner(System.in);
       JTextField searchString = field1;

       // open the data file
       File file = new File("C:\\Users\\Craig\\Documents\\DT211C\\Year 2\\Semester 2\\Programming (Susan Mckeever)\\Labs\\names.txt");

       // create a scanner for/from the file
       Scanner inputFile = new Scanner (file);

       // create an array list
       ArrayList al = new ArrayList();
       
       // Loop to add each line in file to the array list
       while (inputFile.hasNext()){
           al.add(inputFile.next());
       }
       

       //Check if user input is a match and if true print out info
       if(al.contains(field1.getText()) ==true)
       {
    	   JOptionPane.showMessageDialog(null, "Country found");
       		//System.out.println("Country found");
       }
       else
       {
    	   JOptionPane.showMessageDialog(null, "Country not found");
       	//System.out.println("Country not found");
       }

       // close the file
       inputFile.close();
	    }
	   
   	public void actionPerformed(ActionEvent e) {
   		if (e.getSource() == button1){
   			
   		try {
			checkname();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
   			
   			
   			
   		} else {
   			JOptionPane.showMessageDialog(null, "Invalid Option");
   		}
   	}
	   
}
	




