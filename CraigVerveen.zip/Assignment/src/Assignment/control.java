package Assignment;

public class control {

	public static void main(String[] args) {
		
	    gui myscreen;
		myscreen = new gui("My screen");

	}

}
