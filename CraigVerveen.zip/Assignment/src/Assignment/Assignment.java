package Assignment;

import java.util.ArrayList;
import java.util.Scanner;      // Required for the scanner
import java.io.File;               // Needed for File and IOException 
import java.io.FileNotFoundException; //Required for exception throw

public class Assignment {

	public static void main(String[] args) throws FileNotFoundException // Throws Clause Added
    {
        // ask the user for the search string
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Please enter country: ");
        String searchString = keyboard.nextLine();;

        // open the data file
        File file = new File("C:\\Users\\Craig\\Documents\\DT211C\\Year 2\\Semester 2\\Programming (Susan Mckeever)\\Labs\\names.txt");

        // create a scanner for/from the file
        Scanner inputFile = new Scanner (file);

        // create an array list
        ArrayList al = new ArrayList();
        
        // Loop to add each line in file to the array list
        while (inputFile.hasNext()){
            al.add(inputFile.next());
        }
        

        //Check if user input is a match and if true print out info
        if(al.contains(searchString) ==true)
        {
        	System.out.println("String Found In File");
        }
        else
        {
        	System.out.println("String Not Found In File");
        }

        // close the file
        inputFile.close();
    }

}
